var burger = document.querySelector('.burger')
var open = document.querySelector('.header-menu-open')
var close = document.querySelector('.header-menu-close')
var dropdown = document.querySelector('.header-menu-dropdown')
var main = document.querySelector('main')
var footer = document.querySelector('footer')
function toggleMenu() {
    open.classList.toggle('toggle-icon-off')
    close.classList.toggle('toggle-icon-off')
    dropdown.classList.toggle('toggle-icon-off')
    main.classList.toggle('toggle-icon-off')
    footer.classList.toggle('toggle-icon-off')
    document.getElementsByClassName('header-menu-open').style.zIndex = "1"
    document.getElementsByClassName('header-menu-close').style.zIndex = "3"
}

burger.addEventListener('click', () => {
    toggleMenu()
})