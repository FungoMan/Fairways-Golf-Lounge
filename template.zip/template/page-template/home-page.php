<?php
/*
  Template name: Home Page
*/
?>
<?=get_header() ?>
<main>
  <div class="content-wrapper">
    <div class="background-img"> 
      <?php $img = get_field('img') ?>
      <img src="<?= $img['url'] ?>" alt="">
    </div>
    <div class="content">
     <p><?= get_field('motto') ?></p>
      <a href="#" class="download">Download the app</a>
    </div>
  </div>

  <div class="wrapper">
      <div class="content-img-left">
        <?php $img1 = get_field("content1_image1") ?>
        <img src="<?= $img1['url'] ?>" alt="partner">
      </div>  
      <div class="content-title-right">
        <h2><?= get_field("content1_tittle1") ?> </h2>
      </div>
    </div>
 
  <div class="wrapper odd">
      <div class="content-title-left">
      <h2><?= get_field("content2_tittle2") ?> </h2>
      </div>
      <div class="content-img-right">
      <?php $img2 = get_field("content2_image2") ?>
        <img src="<?= $img2['url'] ?>" alt="partner">
      </div>  
      </div>
    </div>   

    
  <div class="wrapper">
      <div class="content-img-left">
      <?php $img3 = get_field("content3_image3") ?>
        <img src="<?= $img3['url'] ?>" alt="partner">
      </div>
      <div class="content-title-right">
      <h2><?= get_field("content3_tittle3") ?> </h2>
      </div>
    </div>

  
  <div class="wrapper odd">
      <div class="content-title-left last">
      <h2><?= get_field("content4_tittle4") ?> </h2>
      </div>
      <div class="content-img-right">
      <?php $img4 = get_field("content4_image4") ?>
        <img src="<?= $img4['url'] ?>" alt="partner">
      </div>  
      </div>
    </div>   


    <!--INSTAGRAM--> 
    <!-- <div  class="container Instagram">
            <h3 >Our latest posts on Instagram</h3>
            <div class="post-grid">
                <?php $posts=get_field("instagram")?>
                <?php foreach($posts as $post): ?>
                    <a  target="<?= $post["link-insta"]["target"]?>" href="<?=$post["link-insta"]["url"]?>"><img class="post" src="<?= $post["img"]["url"]?>"></a>
                <?php endforeach ?>
            </div>
        </div> -->
  
   <!--Comment-->
 
  <!-- <div class="comment">
    <div class="comment-wrapper">
      <div class="comment-containt">
    <div class="comment-content">
      <p>Recently, Twitter has enabled Voice Tweet and WisePass will take advantage of this new form of posting to share about some specific topic, you can enjoy follow our tweets and look at the 20 latest tweets! </p> 
    </div>
    <ul class="comment-tweet-list">
      <li class="comment-tweet-item">
       <div class="tweet-avatar-wrapper">
         <a href="#">
           <img class="tweet-avatar" src="https://pbs.twimg.com/profile_images/858578860677382144/zL5UAqV8_normal.jpg" alt="">
         </a>
       </div>
       <div class="tweet-text-wrapper">
         <div class="tweet-content">
          <div class="tweet-form">
            <a href="#">Wisepass</a>
          </div>
          <div class="tweet-text">
            How about the redemptions of WisePass at the venues?
            <a href="#">https://t.co/A8tRqBbnHu</a>
          </div>
          <div class="tweet-time">
            <a href="#">May 8, 2022, 4:31 PM</a>
          </div> 
       </div>
       </div>
      </li>
      <li class="comment-tweet-item">
       <div class="tweet-avatar-wrapper">
         <a href="#">
           <img class="tweet-avatar" src="https://pbs.twimg.com/profile_images/858578860677382144/zL5UAqV8_normal.jpg" alt="">
         </a>
       </div>
       <div class="tweet-text-wrapper">
         <div class="tweet-content">
          <div class="tweet-form">
            <a href="#">Wisepass</a>
          </div>
          <div class="tweet-text">
            How about the redemptions of WisePass at the venues?
            <a href="#">https://t.co/A8tRqBbnHu</a>
          </div>
          <div class="tweet-time">
            <a href="#">May 8, 2022, 4:31 PM</a>
          </div> 
       </div>
       </div>
      </li>
      <li class="comment-tweet-item">
       <div class="tweet-avatar-wrapper">
         <a href="#">
           <img class="tweet-avatar" src="https://pbs.twimg.com/profile_images/858578860677382144/zL5UAqV8_normal.jpg" alt="">
         </a>
       </div>
       <div class="tweet-text-wrapper">
         <div class="tweet-content">
          <div class="tweet-form">
            <a href="#">Wisepass</a>
          </div>
          <div class="tweet-text">
            How about the redemptions of WisePass at the venues?
            <a href="#">https://t.co/A8tRqBbnHu</a>
          </div>
          <div class="tweet-time">
            <a href="#">May 8, 2022, 4:31 PM</a>
          </div> 
       </div>
       </div>
      </li>
      <li class="comment-tweet-item">
       <div class="tweet-avatar-wrapper">
         <a href="#">
           <img class="tweet-avatar" src="https://pbs.twimg.com/profile_images/858578860677382144/zL5UAqV8_normal.jpg" alt="">
         </a>
       </div>
       <div class="tweet-text-wrapper">
         <div class="tweet-content">
          <div class="tweet-form">
            <a href="#">Wisepass</a>
          </div>
          <div class="tweet-text">
            How about the redemptions of WisePass at the venues?
            <a href="#">https://t.co/A8tRqBbnHu</a>
          </div>
          <div class="tweet-time">
            <a href="#">May 8, 2022, 4:31 PM</a>
          </div> 
       </div>
       </div>
      </li>
      <li class="comment-tweet-item">
       <div class="tweet-avatar-wrapper">
         <a href="#">
           <img class="tweet-avatar" src="https://pbs.twimg.com/profile_images/858578860677382144/zL5UAqV8_normal.jpg" alt="">
         </a>
       </div>
       <div class="tweet-text-wrapper">
         <div class="tweet-content">
          <div class="tweet-form">
            <a href="#">Wisepass</a>
          </div>
          <div class="tweet-text">
            How about the redemptions of WisePass at the venues?
            <a href="#">https://t.co/A8tRqBbnHu</a>
          </div>
          <div class="tweet-time">
            <a href="#">May 8, 2022, 4:31 PM</a>
          </div> 
       </div>
       </div>
      </li>
      <li class="comment-tweet-item">
       <div class="tweet-avatar-wrapper">
         <a href="#">
           <img class="tweet-avatar" src="https://pbs.twimg.com/profile_images/858578860677382144/zL5UAqV8_normal.jpg" alt="">
         </a>
       </div>
       <div class="tweet-text-wrapper">
         <div class="tweet-content">
          <div class="tweet-form">
            <a href="#">Wisepass</a>
          </div>
          <div class="tweet-text">
            How about the redemptions of WisePass at the venues?
            <a href="#">https://t.co/A8tRqBbnHu</a>
          </div>
          <div class="tweet-time">
            <a href="#">May 8, 2022, 4:31 PM</a>
          </div> 
       </div>
       </div>
      </li>
      <li class="comment-tweet-item">
       <div class="tweet-avatar-wrapper">
         <a href="#">
           <img class="tweet-avatar" src="https://pbs.twimg.com/profile_images/858578860677382144/zL5UAqV8_normal.jpg" alt="">
         </a>
       </div>
       <div class="tweet-text-wrapper">
         <div class="tweet-content">
          <div class="tweet-form">
            <a href="#">Wisepass</a>
          </div>
          <div class="tweet-text">
            How about the redemptions of WisePass at the venues?
            <a href="#">https://t.co/A8tRqBbnHu</a>
          </div>
          <div class="tweet-time">
            <a href="#">May 8, 2022, 4:31 PM</a>
          </div> 
       </div>
       </div>
      </li>
    </ul>
    </div>
    </div>

  </div> -->

  
  <!--BLOG-->

  <div class="container Instagram">
    <h3 >Our latest posts on Instagram</h3>
    <div class="post-grid">
     
    <?php $aas=get_field("instagram");
    echo var_dump($aas); ?>
    <?php foreach($aas as $aa): ?>
                    <a  target="<?= $aa["link-insta"]["target"]?>" href="<?=$aa["link-insta"]["url"]?>"><img class="post" src="<?= $aa["img"]["url"]?>"></a>
                <?php endforeach ?>  
  </div>
  </div>
 </main>
    <script type="text/javascript"></script>
  <?=get_footer() ?>

    