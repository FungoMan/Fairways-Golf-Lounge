
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WisePass - Enjoy life everyday</title> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css%22%3E">
  <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/main-style.css">
  <link rel="icon" href="https://images.squarespace-cdn.com/content/v1/610a9bcf401f997808c5b292/99fbd573-e67d-42a1-9d90-734bc9f3a507/favicon.ico?format=100w" sizes="102x102">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer">
</head>
  <div class="header-bar">
    <div class="header-logo">
      <a href="#">
        <img src="https://images.squarespace-cdn.com/content/v1/610a9bcf401f997808c5b292/234b533d-1226-4936-b3c1-896bc440877d/WisePass_Logo_Horizontal_CMYK_HiRes+%281%29.png?format=1500w" alt="logo">
      </a>
    </div>
<!--BURGER-->

  <button class="burger">
    <div class="header-menu-open">
    <i class="bi bi-list"></i>
    </div>
    <div class="header-menu-close toggle-icon-off">
     <img src="<?= get_template_directory_uri()?>/access/close.png" alt="">
    </div>
  </button>
<!--  -->
  </div>
  <!-- <button class="burger">
    <div class="header-menu-icon toggle-icon-off ">
        X    
    </div>
    <div class="header-menu-button ">
      <div class="menu">  
        <div class="menu-top "></div>
        <div class="menu-mid "></div>
        <div class="menu-bot "></div>
      </div>
    </div>
  </button>

  <div class="box-model toggle-icon-off">
  <div class="header-menu toggle-icon-off">
    <div class="header-menu-folder-content">
      <div class="container header-menu-nav-item">
        <a href="#">Get the app</a>
      </div>
      <div class="container header-menu-nav-item">
        <a href="#">Get the app</a>
      </div>
      <div class="container header-menu-nav-item">
        <a href="#">Get the app</a>
      </div>
      <div class="container header-menu-nav-item">
        <a href="#">Get the app</a>
      </div>
      <div class="container header-menu-nav-item">
        <a href="#">Get the app</a>
      </div>
      <div class="container header-menu-nav-item">
        <a href="#">Get the app</a>
      </div>
      <div class="container header-menu-nav-item">
        <a href="#">Get the app</a>
      </div>
  </div>
  </div>
  
  </div> -->

  
  </div>  
  <body>


