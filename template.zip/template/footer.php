</body>
<!--Footer-->
<footer>
    <div class="footer-wrapper">
        <div class="footer-content">
            <div class="footer-follow">
                Follow us
            </div>
            <div class="footer-social-media">
            <i class="fa-brands fa-facebook-f"></i>
            <i class="fa-brands fa-twitter"></i>
            <i class="fa-brands fa-linkedin-in"></i>
            <i class="fa-brands fa-instagram"></i>
            <i class="fa-brands fa-youtube"></i>
            </div>
            <div class="footer-conditions">
                <a href="#">Terms and Conditions</a>
            </div>
            <div class="footer-news">
                News about WisePass
            </div>
        </div>
    </div>
</footer>

<script type="text/javascript" src="<?php echo get_template_directory_uri()?>/page.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" ></script>

</html>
