<?=get_header()?>
  <main>
    <h3>This single page</h3>
  </main>
<?=get_footer()?>
